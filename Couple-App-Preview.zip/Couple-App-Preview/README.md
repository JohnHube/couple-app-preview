# CoupleApp Preview

Dies ist eine funktionale Vorschau einer Web-App für Paare nach der Geburt eines Kindes.

## 📁 Struktur
